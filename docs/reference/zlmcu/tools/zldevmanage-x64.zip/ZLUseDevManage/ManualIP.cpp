// ManualIP.cpp : implementation file
//

#include "stdafx.h"
#include "zlusedevmanage.h"
#include "ZLUseDevManage.h"
#include "ManualIP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CManualIP dialog

extern tZLDM_AddManualDev	m_pZLDM_AddManualDev;
extern tZLDM_ClearManualDev		m_pZLDM_ClearManualDev;

CManualIP::CManualIP(CWnd* pParent /*=NULL*/)
	: CDialog(CManualIP::IDD, pParent)
{
	//{{AFX_DATA_INIT(CManualIP)
	m_ManualIP = _T("192.168.1.200");
	m_ManualPort = 1092;
	m_ManualIP2 = _T("");
	//}}AFX_DATA_INIT
}


void CManualIP::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManualIP)
	DDX_Text(pDX, IDC_MANUAL_IP, m_ManualIP);
	DDV_MaxChars(pDX, m_ManualIP, 29);
	DDX_Text(pDX, IDC_MANUAL_PORT, m_ManualPort);
	DDV_MinMaxUInt(pDX, m_ManualPort, 0, 65536);
	DDX_Text(pDX, IDC_MANUAL_IP2, m_ManualIP2);
	DDV_MaxChars(pDX, m_ManualIP2, 29);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CManualIP, CDialog)
	//{{AFX_MSG_MAP(CManualIP)
	ON_BN_CLICKED(ID_ADD_IP, OnAddIp)
	ON_BN_CLICKED(ID_CLEAR_IP, OnClearIp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManualIP message handlers

void CManualIP::OnAddIp() 
{
	CString str2;
	UpdateData(TRUE);
	if((*m_pZLDM_AddManualDev)((LPCSTR)m_ManualIP, (LPCSTR)m_ManualIP2, m_ManualPort) == TRUE)
	{
		str2.LoadString(ZL_STR_MANUAL_ADD_OK);
		AfxMessageBox(str2);
	}
	else
	{
		str2.LoadString(ZL_STR_MANUAL_ADD_FAIL);
		AfxMessageBox(str2);
	}	
}

void CManualIP::OnClearIp() 
{
	(*m_pZLDM_ClearManualDev)();
}
