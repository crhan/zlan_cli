#if !defined(AFX_MANUALIP_H__7B649DBD_720A_448C_8C76_040609F42DC2__INCLUDED_)
#define AFX_MANUALIP_H__7B649DBD_720A_448C_8C76_040609F42DC2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ManualIP.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CManualIP dialog

class CManualIP : public CDialog
{
// Construction
public:
	CManualIP(CWnd* pParent = NULL);   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CManualIP)
	enum { IDD = IDD_MANUAL };
	CString	m_ManualIP;
	UINT	m_ManualPort;
	CString	m_ManualIP2;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManualIP)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CManualIP)
	afx_msg void OnAddIp();
	afx_msg void OnClearIp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANUALIP_H__7B649DBD_720A_448C_8C76_040609F42DC2__INCLUDED_)
