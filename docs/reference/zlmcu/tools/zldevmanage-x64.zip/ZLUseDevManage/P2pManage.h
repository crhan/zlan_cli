#if !defined(AFX_P2PMANAGE_H__58B62FE6_CE64_427A_99DF_59B211B32A32__INCLUDED_)
#define AFX_P2PMANAGE_H__58B62FE6_CE64_427A_99DF_59B211B32A32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// P2pManage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CP2pManage dialog
#define DEV_COL_P2P_ID		0
#define DEV_COL_P2P_PORT	1
#define DEV_COL_P2P_STATUS	2

class CP2pManage : public CDialog
{
// Construction
public:
	CP2pManage(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CP2pManage)
	enum { IDD = IDD_P2P_MANAGE };
	CListCtrl	m_P2pList;
	CString	m_P2pID;
	UINT	m_SimulatePort;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CP2pManage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CP2pManage)
	afx_msg void OnP2pAdd();
	afx_msg void OnP2pDel();
	virtual BOOL OnInitDialog();
	afx_msg void OnP2pRefresh();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_P2PMANAGE_H__58B62FE6_CE64_427A_99DF_59B211B32A32__INCLUDED_)
