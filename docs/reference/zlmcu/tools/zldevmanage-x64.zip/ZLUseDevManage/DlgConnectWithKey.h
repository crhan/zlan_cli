#if !defined(AFX_DLGCONNECTWITHKEY_H__4BE94672_6E54_4E93_8E68_12EC90211837__INCLUDED_)
#define AFX_DLGCONNECTWITHKEY_H__4BE94672_6E54_4E93_8E68_12EC90211837__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DlgConnectWithKey.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlgConnectWithKey dialog

class CDlgConnectWithKey : public CDialog
{
// Construction
public:
	CDlgConnectWithKey(CWnd* pParent = NULL);   // standard constructor
	CAsyncSocket m_socket;

// Dialog Data
	//{{AFX_DATA(CDlgConnectWithKey)
	enum { IDD = IDD_NEED_KEY };
	CString	m_ConnectIP;
	CString	m_ConnectKey;
	UINT	m_ConnectPort;
	CString	m_NewKey;
	CString	m_OldKey;
	CString	m_SendData;
	CString	m_ModifyKeyDevID;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlgConnectWithKey)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlgConnectWithKey)
	afx_msg void OnConnectWithKey();
	afx_msg void OnModifyKey();
	afx_msg void OnSendTest();
	afx_msg void OnAuthDevValid();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLGCONNECTWITHKEY_H__4BE94672_6E54_4E93_8E68_12EC90211837__INCLUDED_)
