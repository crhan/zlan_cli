// P2pManage.cpp : implementation file
//

#include "stdafx.h"
#include "zlusedevmanage.h"
#include "P2pManage.h"
#include "../ZLDevManage/ZLDevManageDll.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern tZLDM_GetDevParamString		m_pZLDM_GetDevParamString;
extern tZLDM_GetDevParamInt		m_pZLDM_GetDevParamInt;
extern tZLDM_P2pOpen 	m_pZLDM_P2pOpen;
extern tZLDM_P2pClose 	m_pZLDM_P2pClose;
extern tZLDM_P2pAddPort  m_pZLDM_P2pAddPort;
extern tZLDM_P2pDelPort  m_pZLDM_P2pDelPort;
extern tZLDM_P2pRestartAll  m_pZLDM_P2pRestartAll;
extern tZLDM_P2pGetID  m_pZLDM_P2pGetID;
extern tZLDM_P2pRetartPort  m_pZLDM_P2pRetartPort;

/////////////////////////////////////////////////////////////////////////////
// CP2pManage dialog

CP2pManage::CP2pManage(CWnd* pParent /*=NULL*/)
	: CDialog(CP2pManage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CP2pManage)
	m_P2pID = _T("");
	m_SimulatePort = 1235;
	//}}AFX_DATA_INIT
}


void CP2pManage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CP2pManage)
	DDX_Control(pDX, IDC_P2P_LIST, m_P2pList);
	DDX_Text(pDX, IDC_P2P_ID, m_P2pID);
	DDX_Text(pDX, IDC_SIMULATE_PORT, m_SimulatePort);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CP2pManage, CDialog)
	//{{AFX_MSG_MAP(CP2pManage)
	ON_BN_CLICKED(IDC_P2P_ADD, OnP2pAdd)
	ON_BN_CLICKED(IDC_P2P_DEL, OnP2pDel)
	ON_BN_CLICKED(IDC_P2P_REFRESH, OnP2pRefresh)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CP2pManage message handlers

BOOL CP2pManage::OnInitDialog() 
{
	CString str2;

	CDialog::OnInitDialog();

	// �豸�б���ʼ��
	m_P2pList.SetExtendedStyle(m_P2pList.GetExtendedStyle() 
		| LVS_EX_FULLROWSELECT //֧������ѡ��
		//| LVS_EX_GRIDLINES		//��ʾ����
		//| LVS_EX_HEADERDRAGDROP	// ֧���е��϶�		
	);
	str2.LoadString(ZL_STR_DEV_ID);
	m_P2pList.InsertColumn(DEV_COL_P2P_ID, str2, LVCFMT_LEFT, 150);

	str2.LoadString(ZL_STR_DEV_PORT);
	m_P2pList.InsertColumn(DEV_COL_P2P_PORT, str2, LVCFMT_LEFT, 120);

	str2.LoadString(ZL_STR_DEV_STATUS);
	m_P2pList.InsertColumn(DEV_COL_P2P_STATUS, str2, LVCFMT_LEFT, 200);
	
	// ��P2P���ظ��򿪲���������
	m_pZLDM_P2pOpen("www.i-zlan.com", 0, "zlp2psdk", "zlan", 10);	

	OnP2pRefresh();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CP2pManage::OnP2pAdd() 
{
	UpdateData(TRUE);
	m_pZLDM_P2pAddPort(m_SimulatePort, m_P2pID, NULL, NULL);

	OnP2pRefresh();
}

void CP2pManage::OnP2pDel() 
{
	POSITION pos;
	int cursel;
	int CurSelPort;

	// get current sel row
	pos = m_P2pList.GetFirstSelectedItemPosition();
	cursel = m_P2pList.GetNextSelectedItem(pos);

	// get simulate port from current sel port
	CurSelPort = atoi(m_P2pList.GetItemText(cursel, DEV_COL_P2P_PORT));

	m_pZLDM_P2pDelPort(CurSelPort);
	
	OnP2pRefresh();
}


void CP2pManage::OnP2pRefresh() 
{
	int i;
	const char *p_id;
	CString id, str;
	int val, param;

	m_P2pList.DeleteAllItems();
	
	// load all list

	for(i = 0; ; i++)
	{
		if((p_id = (*m_pZLDM_P2pGetID)(i)) == NULL)
			return;
		id = p_id;

		// get data of id

		m_P2pList.InsertItem(i, "1");

		// id
		m_P2pList.SetItemText(i, DEV_COL_P2P_ID, id);

		// port
		val = m_pZLDM_GetDevParamInt(id, PARAM_SIMULATE_PORT);
		str.Format("%d", val);
		m_P2pList.SetItemText(i, DEV_COL_P2P_PORT, str);

		// status
#ifdef ZL_ENG
		param = PARAM_P2P_STATUS_EN;
#else
		param = PARAM_P2P_STATUS_CHS;
#endif
		str = m_pZLDM_GetDevParamString(id, param);
		m_P2pList.SetItemText(i, DEV_COL_P2P_STATUS, str);

	}
}
