// ZLUseDevManage.h : main header file for the ZLUSEDEVMANAGE application
//

#if !defined(AFX_ZLUSEDEVMANAGE_H__24FE9E69_33E8_4C0A_8C50_5AD8EA64595B__INCLUDED_)
#define AFX_ZLUSEDEVMANAGE_H__24FE9E69_33E8_4C0A_8C50_5AD8EA64595B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


/////////////////////////////////////////////////////////////////////////////
// CZLUseDevManageApp:
// See ZLUseDevManage.cpp for the implementation of this class
//

class CZLUseDevManageApp : public CWinApp
{
public:
	CZLUseDevManageApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZLUseDevManageApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CZLUseDevManageApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZLUSEDEVMANAGE_H__24FE9E69_33E8_4C0A_8C50_5AD8EA64595B__INCLUDED_)
